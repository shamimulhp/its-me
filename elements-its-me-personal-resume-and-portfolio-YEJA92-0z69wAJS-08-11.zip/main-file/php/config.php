<?php


//mailto
$my_email = 'yobi.studio@gmail.com';

//default sucject email 
$default_subject = "Your Default Subject Email";

//massage success 
$success_msg = "Thanks, I will get back to you ASAP";

//captcha
$active_captcha = TRUE;

//uploader
$active_uploader = TRUE;

